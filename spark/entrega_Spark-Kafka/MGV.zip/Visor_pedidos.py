from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json,col, unix_timestamp
from pyspark.sql.types import StructType, StructField, StringType, TimestampType

appName = "Visualizador de pedidos"
master = "local"
KAFKA_SERVERS = "kafkaserver:9092"
TOPIC = "pedidos"

spark = SparkSession.builder \
    .master(master) \
    .appName(appName) \
    .getOrCreate()

# Fixar o nivel de rexistro/log a ERROR
spark.sparkContext.setLogLevel("ERROR")

# Stream de lectura
df = spark \
    .readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", KAFKA_SERVERS) \
    .option("subscribe", TOPIC) \
    .load()

df = df.selectExpr("CAST(value as string)")

schema = StructType(
	[
		StructField('produto',StringType(), True),
		StructField('prezo',StringType(), True),
		StructField('categoria',StringType(), True),
		StructField('cantidade',StringType(),True)
	]
)
# Stream de escritura
# opción truncate = false para poder ver as datas e horas

df2 = df.withColumn('value',from_json('value',schema)).select(col('value.*'))

df2.createOrReplaceTempView('pedidos')

# Esta vez usamos o flow dos pedidos, collemos a suma de prezos como 
# beneficio e o contador de cantidades como unidades pedidas.
# Por defecto, separamos por produto

consulta = spark.sql('SELECT produto,SUM(prezo) as beneficio,COUNT(cantidade) as cantidade from pedidos group by produto')

query = consulta \
    .writeStream \
    .outputMode('complete') \
    .format("console") \
    .option("truncate", False) \
    .start()

query.awaitTermination()

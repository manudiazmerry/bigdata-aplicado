from pyspark.sql import SparkSession
from pyspark.sql.functions import from_json,col
from pyspark.sql.types import StructType, StructField, StringType

appName = "Visor de información de vendas separado por tenda"
master = "local"
KAFKA_SERVERS = "kafkaserver:9092"
TOPIC = "vendas"

spark = SparkSession.builder \
    .master(master) \
    .appName(appName) \
    .getOrCreate()

# Fixar o nivel de rexistro/log a ERROR
spark.sparkContext.setLogLevel("ERROR")

# Stream de lectura
df = spark \
    .readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", KAFKA_SERVERS) \
    .option("subscribe", TOPIC) \
    .load()

df = df.selectExpr("CAST(value as string)")

schema = StructType(
	[
		StructField('tenda',StringType(),True),
		StructField('produto',StringType(), True),
		StructField('prezo',StringType(), True),
		StructField('categoria',StringType(), True)
	]
)
# Stream de escritura
# opción truncate = false para poder ver as datas e horas

df2 = df.withColumn('value',from_json('value',schema)).select(col('value.*'))

df2.createOrReplaceTempView('vendas')

# Separamos por tenda, a suma dos prezos como beneficios, e o número de 
# iteracións como contador
consulta = spark.sql('SELECT tenda, SUM(prezo) as beneficios, COUNT(*) as contador from vendas group by tenda')

query = consulta \
    .writeStream \
    .outputMode('complete') \
    .format("console") \
    .option("truncate", False) \
    .start()

query.awaitTermination()
